package com.taetae98.something.di

annotation class SettingDataStore
