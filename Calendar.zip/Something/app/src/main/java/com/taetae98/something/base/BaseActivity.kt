package com.taetae98.something.base

import androidx.appcompat.app.AppCompatActivity

abstract class BaseActivity : AppCompatActivity()